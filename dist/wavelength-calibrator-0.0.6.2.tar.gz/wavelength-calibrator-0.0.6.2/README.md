# wavelength-calibrator
A UI to facilitate wavelength calibration.
