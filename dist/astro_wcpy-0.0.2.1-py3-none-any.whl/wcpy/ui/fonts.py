# -*- coding: utf-8 -*-
# PyQt5
from PyQt5 import QtGui

# Label font
labelFont = QtGui.QFont()
labelFont.setPointSize(10)

# Table font
tableFont = QtGui.QFont()
tableFont.setPointSize(10)

# Button font
buttonFont = QtGui.QFont()
buttonFont.setPointSize(10)