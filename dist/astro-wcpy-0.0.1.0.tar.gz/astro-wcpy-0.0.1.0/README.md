# wcpy
A UI for wavelength calibration.

## Installation

```
pip install astro-wcpy
```

## Usage

Type `wavelength-calibrator` in command line.