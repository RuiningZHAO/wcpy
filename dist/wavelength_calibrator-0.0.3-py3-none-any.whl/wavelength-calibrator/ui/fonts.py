# PyQt5
from PyQt5 import QtGui

# Table font
table_font = QtGui.QFont()
table_font.setPointSize(10)